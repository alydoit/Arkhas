package com.egyptpricetracker.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.egyptpricetracker.data.AlertRequestDto
import com.egyptpricetracker.data.PriceTrackerApi
import com.egyptpricetracker.data.TrackRequestDto
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TrackedItemUi(
    val listingId: Int,
    val storeKey: String,
    val storeNameAr: String,
    val title: String,
    val url: String,
    val currentPrice: Double,
    val avg90d: Double,
    val targetPrice: Double?,
    val verdict: String,
    val priceHistory: List<Double>,
    val inStock: Boolean
)

data class TrackerUiState(
    val items: List<TrackedItemUi> = sampleItems(),
    val selectedStoreKey: String = "all",
    val serverUrl: String = PriceTrackerApi.DEFAULT_BASE_URL,
    val pendingSharedUrl: String? = null,
    val isFacebookLink: Boolean = false,
    val isLoading: Boolean = false,
    val statusMessage: String? = null
)

class PriceTrackerViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("price_tracker_prefs", Context.MODE_PRIVATE)
    private var api: PriceTrackerApi

    private val _uiState: MutableStateFlow<TrackerUiState>
    val uiState: StateFlow<TrackerUiState>

    init {
        val savedUrl = prefs.getString("server_url", PriceTrackerApi.DEFAULT_BASE_URL)
            ?: PriceTrackerApi.DEFAULT_BASE_URL
        api = PriceTrackerApi.create(savedUrl)
        _uiState = MutableStateFlow(TrackerUiState(serverUrl = savedUrl))
        uiState = _uiState.asStateFlow()
    }

    fun updateServerUrl(newUrl: String) {
        val cleaned = newUrl.trim()
        if (!cleaned.startsWith("http://") && !cleaned.startsWith("https://")) {
            _uiState.update { it.copy(statusMessage = "يجب أن يبدأ رابط الخادم بـ http:// أو https://") }
            return
        }
        val normalized = if (cleaned.endsWith("/")) cleaned else "$cleaned/"
        prefs.edit().putString("server_url", normalized).apply()
        api = PriceTrackerApi.create(normalized)
        _uiState.update { it.copy(serverUrl = normalized, statusMessage = "تم حفظ رابط الخادم بنجاح") }
    }

    fun selectStore(storeKey: String) {
        _uiState.update { it.copy(selectedStoreKey = storeKey) }
    }

    fun onIncomingSharedUrl(rawText: String) {
        val extracted = Regex("https?://\S+").find(rawText)?.value ?: rawText.trim()
        val isFb = extracted.contains("facebook.com", ignoreCase = true) ||
            extracted.contains("fb.com", ignoreCase = true)
        _uiState.update {
            it.copy(
                pendingSharedUrl = extracted,
                isFacebookLink = isFb,
                statusMessage = null
            )
        }
    }

    fun dismissShareSheet() {
        _uiState.update { it.copy(pendingSharedUrl = null, isFacebookLink = false) }
    }

    fun trackUrl(
        url: String,
        targetPrice: Double?,
        manualTitle: String? = null,
        manualPrice: Double? = null,
        fcmToken: String = "demo_fcm_token"
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, statusMessage = null) }
            try {
                val res = api.trackProduct(
                    TrackRequestDto(
                        url = url.trim(),
                        manualPrice = manualPrice,
                        manualTitle = manualTitle?.ifBlank { null }
                    )
                )
                if (targetPrice != null && targetPrice > 0) {
                    api.createAlert(
                        AlertRequestDto(
                            listingId = res.listingId,
                            fcmToken = fcmToken,
                            targetPrice = targetPrice,
                            notifyRestock = true
                        )
                    )
                }
                val price = res.product.price ?: manualPrice ?: 0.0
                val newItem = TrackedItemUi(
                    listingId = res.listingId,
                    storeKey = res.product.storeKey,
                    storeNameAr = res.product.storeNameAr,
                    title = res.product.title,
                    url = res.product.url,
                    currentPrice = price,
                    avg90d = res.analysis?.avg90d ?: price,
                    targetPrice = targetPrice,
                    verdict = res.analysis?.verdict ?: "تحت المراقبة",
                    priceHistory = listOf(price),
                    inStock = res.product.inStock
                )
                _uiState.update { state ->
                    state.copy(
                        items = listOf(newItem) + state.items.filterNot { it.listingId == newItem.listingId },
                        pendingSharedUrl = null,
                        isLoading = false,
                        statusMessage = "تمت إضافة المنتج بنجاح من ${res.product.storeNameAr}"
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        statusMessage = "تعذر الاتصال بالخادم (${_uiState.value.serverUrl}): ${e.localizedMessage}"
                    )
                }
            }
        }
    }
}

private fun sampleItems(): List<TrackedItemUi> = listOf(
    TrackedItemUi(
        listingId = 101,
        storeKey = "amazon_eg",
        storeNameAr = "أمازون مصر",
        title = "تكييف شارب 1.5 حصان انفرتر بارد ساخن",
        url = "https://www.amazon.eg/dp/B0EXAMPLE1",
        currentPrice = 24999.0,
        avg90d = 27800.0,
        targetPrice = 25000.0,
        verdict = "هبوط حقيقي",
        priceHistory = listOf(28200.0, 27900.0, 27500.0, 29100.0, 26400.0, 24999.0),
        inStock = true
    ),
    TrackedItemUi(
        listingId = 102,
        storeKey = "btech",
        storeNameAr = "بي تك",
        title = "غسالة ملابس إل جي 8 كيلو ديجيتال",
        url = "https://btech.com/ar/washer-lg-8kg.html",
        currentPrice = 24500.0,
        avg90d = 24100.0,
        targetPrice = 22500.0,
        verdict = "خصم وهمي محتمل",
        priceHistory = listOf(23800.0, 24000.0, 24200.0, 27900.0, 24500.0),
        inStock = true
    ),
    TrackedItemUi(
        listingId = 103,
        storeKey = "noon_eg",
        storeNameAr = "نون مصر",
        title = "سماعة سوني لاسلكية عازلة للضوضاء",
        url = "https://www.noon.com/egypt-ar/p-12345/",
        currentPrice = 4299.0,
        avg90d = 4950.0,
        targetPrice = 4300.0,
        verdict = "أدنى سعر تاريخي",
        priceHistory = listOf(5200.0, 5050.0, 4900.0, 4700.0, 4299.0),
        inStock = true
    )
)
