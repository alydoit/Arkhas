package com.egyptpricetracker

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.egyptpricetracker.viewmodel.PriceTrackerViewModel
import com.egyptpricetracker.viewmodel.TrackedItemUi

class MainActivity : ComponentActivity() {

    private val viewModel: PriceTrackerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleShareIntent(intent)

        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = lightColorScheme(
                        primary = Color(0xFF065F46),
                        secondary = Color(0xFF1E40AF),
                        background = Color(0xFFFFFFFF),
                        surface = Color(0xFFF8FAFC)
                    )
                ) {
                    PriceTrackerScreen(viewModel)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShareIntent(intent)
    }

    private fun handleShareIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { shared ->
                viewModel.onIncomingSharedUrl(shared)
            }
        }
    }
}

private val STORE_FILTERS = listOf(
    "all" to "الكل",
    "amazon_eg" to "أمازون",
    "carrefour_eg" to "كارفور",
    "jumia_eg" to "جوميا",
    "raneen" to "رنين",
    "noon_eg" to "نون",
    "btech" to "بي تك",
    "raya_shop" to "راية",
    "dream2000" to "دريم 2000",
    "facebook" to "فيسبوك"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PriceTrackerScreen(viewModel: PriceTrackerViewModel) {
    val state by viewModel.uiState.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var showServerDialog by remember { mutableStateOf(false) }

    val filteredItems = remember(state.items, state.selectedStoreKey) {
        if (state.selectedStoreKey == "all") state.items
        else state.items.filter { it.storeKey == state.selectedStoreKey }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("راصد الأسعار — مصر", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { showServerDialog = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "إعدادات الخادم")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                icon = { Icon(Icons.Default.Add, contentDescription = "إضافة منتج") },
                text = { Text("مراقبة رابط") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                items(STORE_FILTERS) { (key, label) ->
                    FilterChip(
                        selected = state.selectedStoreKey == key,
                        onClick = { viewModel.selectStore(key) },
                        label = { Text(label) }
                    )
                }
            }

            state.statusMessage?.let { msg ->
                Text(
                    text = msg,
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(filteredItems, key = { it.listingId }) { item ->
                    ProductPriceCard(item)
                }
            }
        }
    }

    if (showAddDialog || state.pendingSharedUrl != null) {
        AddProductDialog(
            initialUrl = state.pendingSharedUrl.orEmpty(),
            isFacebookHint = state.isFacebookLink,
            isLoading = state.isLoading,
            onDismiss = {
                showAddDialog = false
                viewModel.dismissShareSheet()
            },
            onConfirm = { url, target, fbTitle, fbPrice ->
                showAddDialog = false
                viewModel.trackUrl(
                    url = url,
                    targetPrice = target,
                    manualTitle = fbTitle,
                    manualPrice = fbPrice
                )
            }
        )
    }

    if (showServerDialog) {
        ServerUrlDialog(
            currentUrl = state.serverUrl,
            onDismiss = { showServerDialog = false },
            onSave = { newUrl ->
                showServerDialog = false
                viewModel.updateServerUrl(newUrl)
            }
        )
    }
}

@Composable
private fun ServerUrlDialog(
    currentUrl: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var urlInput by remember(currentUrl) { mutableStateOf(currentUrl) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("عنوان خادم تتبع الأسعار") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "أدخل رابط خادم FastAPI (مثلاً http://192.168.1.5:8000/ للتجربة على نفس الواي فاي):",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF475569)
                )
                OutlinedTextField(
                    value = urlInput,
                    onValueChange = { urlInput = it },
                    label = { Text("Server Base URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSave(urlInput) }) { Text("حفظ") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
private fun ProductPriceCard(item: TrackedItemUi) {
    val verdictColor = when {
        item.verdict.contains("وهمي") -> Color(0xFFB91C1C)
        item.verdict.contains("هبوط") || item.verdict.contains("أدنى") -> Color(0xFF065F46)
        else -> Color(0xFF334155)
    }

    OutlinedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.storeNameAr,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.secondary
                )
                Text(
                    text = item.verdict,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = verdictColor
                )
            }

            Spacer(Modifier.height(6.dp))
            Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${"%,.0f".format(item.currentPrice)} ج.م",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "متوسط 90 يوم: ${"%,.0f".format(item.avg90d)} ج.م",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF475569)
                )
            }

            if (item.priceHistory.size >= 2) {
                Spacer(Modifier.height(10.dp))
                PriceSparkline(prices = item.priceHistory, target = item.targetPrice)
            }
        }
    }
}

@Composable
private fun PriceSparkline(prices: List<Double>, target: Double?) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
    ) {
        val allVals = prices + listOfNotNull(target)
        val minVal = allVals.minOrNull() ?: 0.0
        val maxVal = (allVals.maxOrNull() ?: 1.0).coerceAtLeast(minVal + 1.0)
        val stepX = size.width / (prices.size - 1).coerceAtLeast(1)

        fun yFor(v: Double): Float {
            val norm = ((v - minVal) / (maxVal - minVal)).toFloat()
            return size.height - (norm * (size.height - 8f)) - 4f
        }

        target?.let {
            val ty = yFor(it)
            drawLine(
                color = Color(0xFF059669),
                start = Offset(0f, ty),
                end = Offset(size.width, ty),
                strokeWidth = 2f
            )
        }

        val path = Path()
        prices.forEachIndexed { idx, p ->
            val x = idx * stepX
            val y = yFor(p)
            if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
            path = path,
            color = Color(0xFF0F172A),
            style = Stroke(width = 4f, cap = StrokeCap.Round)
        )
    }
}

@Composable
private fun AddProductDialog(
    initialUrl: String,
    isFacebookHint: Boolean,
    isLoading: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (url: String, targetPrice: Double?, fbTitle: String?, fbPrice: Double?) -> Unit
) {
    var url by remember(initialUrl) { mutableStateOf(initialUrl) }
    var targetPriceText by remember { mutableStateOf("") }
    var fbTitle by remember { mutableStateOf("") }
    var fbPriceText by remember { mutableStateOf("") }
    val showFbFields = isFacebookHint || url.contains("facebook.com", ignoreCase = true)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة منتج للمراقبة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("رابط المنتج") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = targetPriceText,
                    onValueChange = { targetPriceText = it },
                    label = { Text("السعر المستهدف للتنبيه (ج.م)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                if (showFbFields) {
                    Text(
                        text = "روابط فيسبوك تتطلب إدخال السعر المبدئي يدوياً بسبب قيود تسجيل الدخول:",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF475569)
                    )
                    OutlinedTextField(
                        value = fbTitle,
                        onValueChange = { fbTitle = it },
                        label = { Text("اسم المنتج على فيسبوك") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = fbPriceText,
                        onValueChange = { fbPriceText = it },
                        label = { Text("السعر الحالي على فيسبوك (ج.م)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = url.isNotBlank() && !isLoading,
                onClick = {
                    onConfirm(
                        url,
                        targetPriceText.toDoubleOrNull(),
                        fbTitle.ifBlank { null },
                        fbPriceText.toDoubleOrNull()
                    )
                }
            ) {
                Text(if (isLoading) "جاري الحفظ..." else "بدء المراقبة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
