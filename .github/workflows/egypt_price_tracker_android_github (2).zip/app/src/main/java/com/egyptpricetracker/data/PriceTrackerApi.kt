package com.egyptpricetracker.data

import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

data class StoreDto(
    val key: String,
    @SerializedName("name_ar") val nameAr: String,
    val domains: List<String>,
    val tier: String,
    @SerializedName("poll_minutes") val pollMinutes: Int,
    val notes: String
)

data class TrackRequestDto(
    val url: String,
    @SerializedName("manual_price") val manualPrice: Double? = null,
    @SerializedName("manual_title") val manualTitle: String? = null
)

data class ExtractedProductDto(
    @SerializedName("store_key") val storeKey: String,
    @SerializedName("store_name_ar") val storeNameAr: String,
    val url: String,
    val title: String,
    val price: Double?,
    @SerializedName("original_price") val originalPrice: Double?,
    val currency: String,
    @SerializedName("in_stock") val inStock: Boolean,
    @SerializedName("requires_manual_update") val requiresManualUpdate: Boolean
)

data class PriceAnalysisDto(
    @SerializedName("current_price") val currentPrice: Double,
    @SerializedName("avg_90d") val avg90d: Double,
    @SerializedName("min_90d") val min90d: Double,
    @SerializedName("max_90d") val max90d: Double,
    @SerializedName("pct_vs_avg") val pctVsAvg: Double,
    val verdict: String,
    @SerializedName("explanation_ar") val explanationAr: String
)

data class TrackResponseDto(
    @SerializedName("listing_id") val listingId: Int,
    val product: ExtractedProductDto,
    val analysis: PriceAnalysisDto?
)

data class AlertRequestDto(
    @SerializedName("listing_id") val listingId: Int,
    @SerializedName("fcm_token") val fcmToken: String,
    @SerializedName("target_price") val targetPrice: Double? = null,
    @SerializedName("drop_pct") val dropPct: Double? = null,
    @SerializedName("notify_restock") val notifyRestock: Boolean = true
)

data class AlertResponseDto(
    @SerializedName("alert_id") val alertId: Int,
    val status: String
)

interface PriceTrackerApi {
    @GET("api/v1/stores")
    suspend fun getStores(): List<StoreDto>

    @POST("api/v1/track")
    suspend fun trackProduct(@Body body: TrackRequestDto): TrackResponseDto

    @POST("api/v1/alerts")
    suspend fun createAlert(@Body body: AlertRequestDto): AlertResponseDto

    companion object {
        const val DEFAULT_BASE_URL = "http://10.0.2.2:8000/"

        fun create(baseUrl: String = DEFAULT_BASE_URL): PriceTrackerApi {
            val normalized = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
            val logger = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }
            val client = OkHttpClient.Builder()
                .addInterceptor(logger)
                .build()

            return Retrofit.Builder()
                .baseUrl(normalized)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(PriceTrackerApi::class.java)
        }
    }
}
